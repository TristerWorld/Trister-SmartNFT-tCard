const ERC721Tradable = artifacts.require("./ERC721Tradable.sol");
const erc721Name = "Trister's NFT NFT";
const erc721Symbol = "tCard";

const testBaseURI = "Http://test.com/";
const testStepNum = 2;
const testDefaulTokenIdURI = "default.png";
const testTokenIdURI = "test.png";
const toBN = web3.utils.toBN;
/**
 * accounts[0] -- 铸造用户、合约owner,tokendId=[2-10]
 * accounts[1] -- 单个铸用户,tokenId=1
 * accounts[2] -- accounts[0]授权给accounts[2]
 * accounts[3] -- 被accounts[2]转账给accounts[3]
 */
contract("TCardNFT", (accounts) => {
  let erc721;
  before(async () => {
    erc721 = await ERC721Tradable.deployed(erc721Name, erc721Symbol);
  });
  const owner = accounts[0];

  describe("#BaseInfo", async () => {

    //基本数据Case
    it("should get the symbol value", async () => {
      const _name = await erc721.name();
      console.log("name: ", _name);
      assert.ok(erc721Name == _name);
      const _symbol = await erc721.symbol();
      console.log("symbol: ", _symbol);
      assert.ok(erc721Symbol == _symbol);
    });
  });

  //铸造相关的Case
  describe("#mint", async () => {
    //批量铸造Case
    it("mint", async () => {
      //检查当前所有的已经发布的Token总数和当前ID最大值
      let _totalSupply = await erc721.totalSupply();
      let _currentTokenId = await erc721.currentTokenId();
      console.log("totalSupply: %d, currentTokenId:%d", _totalSupply, _currentTokenId);
      
      await erc721.addMinter(accounts[1]);

      let _exist = await erc721.exists(88);
      assert.ok(!_exist);
      await erc721.mintByTokenId(accounts[2],88);
      _exist = await erc721.exists(88);
      assert.ok(_exist);

      await erc721.mintByTokenId(accounts[2],99);
      let arr = await erc721.tokensOfOwner(accounts[2]);
      console.log("arr: ", arr);

      await erc721.mintByTokenId(accounts[0],111);
      arr = await erc721.tokensOfOwner(accounts[0]);
      console.log("arr: ", arr);

      _totalSupply = await erc721.totalSupply();
      _currentTokenId = await erc721.currentTokenId();
      console.log("totalSupply: %d, currentTokenId:%d", _totalSupply, _currentTokenId);
      
      
      let _account0Balance = await erc721.balanceOf(accounts[2]);
      _currentTokenId = await erc721.currentTokenId();
      console.log("account0: %s, balance: %d, currentTokenId:%d", accounts[2], _account0Balance, _currentTokenId);
      assert.ok(_account0Balance.eq(toBN(2)));
    });

  });

  //设置基本数据
  describe("#setConfig", async () => {
    it("setConfig", async () => {
      let _baseTokenURI = await erc721.baseURI();
      console.log("baseTokenURI: %s",  _baseTokenURI);
      //重新部署铸造
      await erc721.setConfig(testBaseURI,testStepNum,true);
  
      _baseTokenURI = await erc721.baseURI();
      console.log("baseTokenURI: %s",  _baseTokenURI);
      assert.ok(_baseTokenURI == testBaseURI);
  
      // let _stepNum = await erc721.stepNum();
      // console.log("stepNum: %s",  _stepNum);
      // assert.ok(_stepNum == testStepNum);
  
      let _tokenURI = await erc721.tokenURI(88);
      console.log("tokenURI: %s",  _tokenURI);
      assert.ok(_tokenURI == (testBaseURI+testDefaulTokenIdURI));
    });
  });

  //用户设置TokenID图标
  describe("#setTokenURI", async () => {
    it("setTokenURI", async () => {
      await erc721.setTokenURI(111, "test.png");
      let _tokenURI = await erc721.tokenURI(111);
      console.log("tokenURI: %s",  _tokenURI);
      assert.ok(_tokenURI == (testBaseURI+testTokenIdURI));
    });  
  });

});
