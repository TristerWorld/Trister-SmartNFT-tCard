const ERC721Tradable = artifacts.require("./ERC721Tradable.sol");
const config = require("../config.json");
const deployments = require("../deployments.json");
const fs = require('fs');
const path = require('path');
const util = require('util');
const writeFile = util.promisify(fs.writeFile);

module.exports = async function (deployer, network) {
  const _name = "tCard";
  const _symbol = "tCard";
  const params = config.networks[network];
  if (!params) {
    console.log(
      "no config was set of network: ",
      network,
      ", please check config.json"
    );
    return;
  }
  const deploymentsNetwork = deployments.networks[network] || {};
  if (network == "mainnet") {
    if (deploymentsNetwork.tcardContractAddress) {
      console.log(
        `tcard: ${tcardContractAddress} has been deployed, if you want to force update, please delete this contract address from deployments.json`
      );
      return;
    }
  }
  await deployer.deploy(ERC721Tradable, _name, _symbol);
  const tcardInstance = await ERC721Tradable.deployed();
  deploymentsNetwork.tcardContractAddress = tcardInstance.address;
  deployments.networks[network] = deploymentsNetwork;
  // write to file
  const deploymentPath = path.resolve(__dirname, `../deployments.json`);
  await writeFile(deploymentPath, JSON.stringify(deployments, null, 2));
};
