const HDWalletProvider = require('truffle-hdwallet-provider');
const web3 = require('web3');
const TCard = require('../build/contracts/ERC721Tradable.json');
const config = require('../config.json');
const deployments = require('../deployments.json');
const miners = require('./miners.json');
const network = 'development'

async function main() {
  const params = config.networks[network]
  if(!params) {
    console.log("no config was set of network: ", network, ", please check config.json")
    return 
  }
  const deploymentsNetwork = deployments.networks[network]
  if(!deploymentsNetwork) {
    console.log("no contract was deployed of network: ", network, ", please check deployments.json")
    return 
  }
  const minersNetwork = miners.networks[network]
  if(!minersNetwork) {
    console.log("no miners was set of network: ", network, ", please check miners.json")
    return 
  }
  const provider = new HDWalletProvider("<YOUR_TESTNET_ADDRESS_PRIVATE_KEY>", 'http://127.0.0.1:7545');
  console.log(deploymentsNetwork, 'deploymentsNetwork')
  console.log(minersNetwork, 'minersNetwork')
  const tcardAddress = deploymentsNetwork.tcardContractAddress;
  const web3Instance = new web3(provider);
  const card = new web3Instance.eth.Contract(TCard.abi, tcardAddress);

  for (const miner of Object.values(minersNetwork.sellers)) {
    const isAdded = await isMinter(web3Instance, card, tcardAddress, miner);
    if (isAdded) {
      console.log(`seller: ${miner} has been added as miner`);
      continue;
    }
    const addMinterResult = await addMinter(web3Instance, card, 20000000000, tcardAddress, miner)
    console.log(`seller: ${miner} was added as miner, result: `, addMinterResult);
  }
}

async function isMinter(web3Instance, card, tcardAddress, sellerAddr) {
  const rawIntput = card.methods.isMinter(sellerAddr).encodeABI();
  const rawResult = await web3Instance.eth.call({
    to: tcardAddress,
    data: rawIntput,
  });

  return web3Instance.eth.abi.decodeParameter(
    "bool",
    rawResult
  )
}

async function addMinter(web3Instance, card, gasPrice, tcardAddress, sellerAddr) {
  console.log(`add ${sellerAddr} to ${tcardAddress} as miner`)
  const rawIntput = card.methods.addMinter(sellerAddr).encodeABI();
  const from = (await web3Instance.eth.getAccounts())[0];
  const nonce = await web3Instance.eth.getTransactionCount(from);
  const estimateGas = web3.utils.hexToNumber(await web3Instance.eth.estimateGas({
    to: tcardAddress,
    data: rawIntput
  }))

  const gasLimit = parseInt(estimateGas * 1.2)

  const rawResult = await web3Instance.eth.sendTransaction({
    from,
    to: tcardAddress,
    gas: gasLimit,
    gasPrice,
    value: '0x0',
    nonce,
    data: rawIntput,
  });
  return rawResult;
}

main();
