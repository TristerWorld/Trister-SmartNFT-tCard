const TCardSeller = artifacts.require('./TCardSeller.sol');
const deployments = require('../deployments.json');
const config = require('../config.json');
const fs = require('fs');
const path = require('path');
const util = require('util');
const writeFile = util.promisify(fs.writeFile);

module.exports = async function (deployer, network, accounts) {
  const name = 'Trister NFT Seller';
  const symbol = 'TNS';
  const params = config.networks[network]
  if(!params) {
    console.log("no config was set of network: ", network, ", please check config.json")
    return 
  }

  const deploymentsNetwork = deployments.networks[network] || {};
  const { sellers = {}} = deploymentsNetwork;
  const versions = params.VERSIONS || []
  for (version of versions) {
      if (network == "mainnet") {
        if (sellers[`${version.id}`]) {
          console.log(`version: ${version.id} has been deployed`);
          continue;
        }
      }
      await deployer.deploy(TCardSeller, name, symbol, version.id, params.TCARD_ADDRES, params.USDT_ADDRESS, version.price);
      const sellerInstance = await TCardSeller.deployed();
      sellers[`${version.id}`] = sellerInstance.address
  }
  deploymentsNetwork.sellers = sellers
  deployments.networks[network] = deploymentsNetwork
  // write to file
  const deploymentPath = path.resolve(__dirname, `../deployments.json`);
  await writeFile(deploymentPath, JSON.stringify(deployments, null, 2));
};
