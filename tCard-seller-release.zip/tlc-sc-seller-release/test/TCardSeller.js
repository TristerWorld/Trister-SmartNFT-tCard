const TCardSeller = artifacts.require("../contracts/TCardSeller.sol");
const web3 = require("web3");

contract("TCardSeller", (accounts) => {
  console.log("accounts", accounts);
  let tCardSeller;
  before(async () => {
    tCardSeller = await TCardSeller.deployed();
  });
  describe("#symbol", async () => {
    it("should get the symbol value", async () => {
      console.log("symbol", await tCardSeller.symbol());
      console.log("name", await tCardSeller.name());
      console.log("tokenAddress", await tCardSeller.tokenAddress());
      console.log("nftAddress", await tCardSeller.nftAddress());
      console.log("nftPrice", await tCardSeller.nftPrice());
      console.log("getStockInfo", await tCardSeller.getStockInfo());
      console.log("getInfo", await tCardSeller.getInfo());
      const earliestStartTime = await tCardSeller.getEarliestStartTime();
      console.log("getEarliestStartTime", earliestStartTime);
      console.log("setParams", await tCardSeller.setParams(earliestStartTime.toNumber(), earliestStartTime.add(web3.utils.toBN(3600)).toNumber(), 1, 1, 2, "0x8793990198172cA4D5127fe03197Df7cd01386D4", []));
      console.log("getInfo", await tCardSeller.getInfo());
      assert.equal("TNS", await tCardSeller.symbol());
    });
  });
});
