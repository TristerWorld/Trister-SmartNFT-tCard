const HDWalletProvider = require('truffle-hdwallet-provider');
const config = require('./config.json');

module.exports = {
  // See <http://truffleframework.com/docs/advanced/configuration>
  // for more about customizing your Truffle configuration!
  networks: {
    development: {
      host: '127.0.0.1',
      port: 7545,
      network_id: '*', // Match any network id
    },
    ropsten: {
      networkCheckTimeout: config.networkCheckTimeout,
      provider: function () {
        return new HDWalletProvider(config.networks.ropsten.PRIVATE_KEY, `https://ropsten.infura.io/v3/${config.infura.PROJECT_ID}`);
      },
      network_id: 3,
    },
    mainet: {
      networkCheckTimeout: config.networkCheckTimeout,
      provider: function () {
        return new HDWalletProvider(config.networks.mainnet.PRIVATE_KEY, `https://mainnet.infura.io/v3/${config.infura.PROJECT_ID}`);
      },
      network_id: 1,
      gasPrice: config.networks.mainnet.GAS_PRICE,
    },
  },
  compilers: {
    solc: {
      version: '^0.5.0',
    },
  },
};
